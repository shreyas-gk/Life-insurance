//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileZilla server.rc
//
#define IDR_MAINFRAME                   10

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         10056
#define _APS_NEXT_SYMED_VALUE           10143
#endif
#endif
